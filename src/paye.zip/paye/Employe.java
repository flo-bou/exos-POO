package src.paye;

public abstract class Employe {
    private String nom;
    private String prenom;
    private int age;
    private String dateEntree;

    public Employe(String nom, String prenom, int age, String dateEntree){
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.dateEntree = dateEntree;
    }

    public String getPrenom(){
        return this.prenom;
    }

    public int getAge(){
        return this.age;
    }

    public String getDateEntree(){
        return this.dateEntree;
    }

    public abstract double calculerSalaire();

    public String getNom(){
        return "L'employé " + this.prenom + " " + this.nom;
    }
}
