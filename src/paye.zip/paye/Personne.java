package src.paye;

public class Personne{
    // private String name;

    // public Personne(String name){
    //     this.name = name;
    // }

    public void direBonjour(){
        System.out.println("Bonjour.");
    }
}