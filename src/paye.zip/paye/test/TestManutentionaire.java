package paye.test;

import org.junit.jupiter.api.Test;
import src.paye.Manutentionaire;

public class TestManutentionaire {

    @Test
    public void testReturnGetTitre(){
        Manutentionaire manu = new Manutentionaire("Henri", "H", 12, "2022-12-04");
//        Assertions.assertTrue();
    }
}
