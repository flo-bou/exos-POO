package src.paye;

import src.paye.Employe;

public class Vendeur extends Employe {
    private double chiffreAffaire;

    public Vendeur(String nom, String prenom, int age, String dateEntree){
        super(nom, prenom, age, dateEntree);
    }

    public void setChiffreAffaire(double chiffreAffaire){
        this.chiffreAffaire = chiffreAffaire;
    }

    public double calculerSalaire(){
        return this.chiffreAffaire * 0.2 + 400;
    }
}
