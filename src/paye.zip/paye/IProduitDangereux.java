package src.paye;

public interface IProduitDangereux {
    static int primeRisque = 200;
    public boolean produitDangereux = false;

    public int getPrimeRisque();
    public boolean getProduitDangereux();
    public boolean setProduitDangereux();
}
