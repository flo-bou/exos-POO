package src.paye;

import src.paye.Personne;

public class Etudiant extends Personne {
    private int age;

    // public Etudiant(String name){
    //     this.name = name;
    // }

    public void setAge(int age){
        this.age = age;
    }

    public void direAge(){
        System.out.println("J'ai " + age + "ans.");
    }

    public void direAllerEnClasse(){
        System.out.println("Je vais en classe au CESI");
    }
}