package src.paye;

import src.paye.Employe;

public class Techos extends Employe {
    private int uniteProduite;

    public Techos(String nom, String prenom, int age, String dateEntree){
        super(nom, prenom, age, dateEntree);
    }

    public void setUniteProduite(int uniteProduite){
        this.uniteProduite = uniteProduite;
    }

    public double calculerSalaire(){
        return this.uniteProduite * 5;
    }
}
