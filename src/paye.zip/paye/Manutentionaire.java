package src.paye;

/*
 * Un manutentionnaire est un
 * @exten
 */
public class Manutentionaire extends Employe implements IProduitDangereux {
    private double heuresTravail;

    public Manutentionaire(String nom, String prenom, int age, String dateEntree){
        super(nom, prenom, age, dateEntree);
    }



// Une méthode qui renvoie la valeur de la variable primeRisque.
    public int getPrimeRisque(){
        return this.primeRisque;
    }


    /**
     * @return boolean
     */
    public boolean getProduitDangereux(){
        return this.produitDangereux;
    }


    /**
     * @param isProduitDangereux
     */
    public void setProduitDangereux(boolean isProduitDangereux){
        this.produitDangereux = isProduitDangereux;
    }


    /**
     * @param heureTravail
     */
    public void setHeureTravail(double heureTravail){
        this.heuresTravail = heureTravail;
    }


    /**
     * @return double
     */
    public double calculerSalaire(){
        return heuresTravail * 65;
    }
}
